#ifndef OPERATIONS_H
#define OPERATIONS_H

#include <string.h>

int double_number(int x);
void print_animal_noise(const char* animal);
int calculate_pizza_slices(int people);

#endif