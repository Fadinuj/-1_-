#include "mathlib.h"
#include <stdio.h> // For printf (optional, for debugging or error messages)

int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}

int multiply(int a, int b) {
    return a * b;
}

double divide(int a, int b) {
    if (b == 0) {
        // Handle division by zero
        printf("Error: Division by zero is undefined.\n");
        return 0.0; // Alternatively, you can return a special value or terminate the program
    }
    return (double)a / b;
}
