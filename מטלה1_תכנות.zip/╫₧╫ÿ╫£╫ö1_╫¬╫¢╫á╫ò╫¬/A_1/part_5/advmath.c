#include "advmath.h"
#include <math.h> // For power and square root functions
#include <stdlib.h>
float average(int arr[], int size) {
    if (size <= 0) return 0.0f; // Handle invalid size
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return (float)sum / size;
}

double power(int base, int exp) {
    double result = 1.0;
    for (int i = 0; i < abs(exp); i++) {
        result *= base;
    }
    return exp < 0 ? 1 / result : result;
}

double square_root(int value) {
    if (value < 0) return -1; // Indicate invalid input
    return sqrt(value);
}

int factorial(int n) {
    if (n < 0) return -1; // Indicate invalid input
    if (n == 0 || n == 1) return 1;
    int result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}