// advmath.h
#ifndef ADVMATH_H
#define ADVMATH_H

float average(int arr[], int size);
double power(int base, int exp);
double square_root(int value);
int factorial(int n);
#endif