#include <stdio.h>
#include <shiny.h>

void make_shiny(void)
{
    printf("*sparkle* *sparkle* *shine*\n");
}