#ifndef SHINY_H
#define SHINY_H

void make_shiny(void);

#endif