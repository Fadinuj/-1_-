#include "advmath.h"
#include <math.h> // לשימוש בפונקציות מתמטיות כמו sqrt

float average(int arr[], int size) {
    if (size <= 0) return 0; 
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return (float)sum / size;
}

double power(double base, int exponent) {
    double result = 1.0;
    for (int i = 0; i < exponent; i++) {
        result *= base;
    }
    return exponent < 0 ? 1 / result : result;
}

int factorial(int n) {
    if (n < 0) return 0; 
    int result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

double square_root(double num) {
    if (num < 0) return -1; // הגנה למספרים שליליים
    return sqrt(num);
}